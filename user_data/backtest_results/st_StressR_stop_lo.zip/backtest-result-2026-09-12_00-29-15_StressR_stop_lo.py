
from regime_router import RegimeRouter as _Base


class StressR_stop_lo(_Base):
    """perturbed:     TL_ATR_STOP = 2.7
    TS_ATR_STOP = 2.7
    MR_ATR_STOP = 1.8"""
    TL_ATR_STOP = 2.7
    TS_ATR_STOP = 2.7
    MR_ATR_STOP = 1.8
