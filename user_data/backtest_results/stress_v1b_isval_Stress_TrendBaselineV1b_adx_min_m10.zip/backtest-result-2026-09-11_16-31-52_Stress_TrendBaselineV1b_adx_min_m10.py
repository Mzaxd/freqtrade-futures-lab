
from TrendBaselineV1b import TrendBaselineV1b as _Base
from freqtrade.strategy import IntParameter, DecimalParameter


class Stress_TrendBaselineV1b_adx_min_m10(_Base):
    """Perturbed: adx_min: 17 -> 15 (-10%)"""

    adx_min = IntParameter(15, 30, default=15, space='buy')
