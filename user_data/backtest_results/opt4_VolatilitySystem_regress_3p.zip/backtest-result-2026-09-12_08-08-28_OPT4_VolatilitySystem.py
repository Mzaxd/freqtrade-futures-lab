# OPT4_VolatilitySystem — Phase-4 deep-optimized VolatilitySystem (G×H merge).
#
# Composition (all components validated independently within 20210101-20240101,
# see research_openstrat/reports/phase4_{charter,paramtune,structure}.md):
#   * OPT1 risk structure (unchanged): ATR-anchored initial stop, 1%-equity risk
#     sizing, no DCA, 2x leverage, catastrophe cap -0.30.
#   * atr08 entry gate (Agent-H winner): new entries (both sides) only when the
#     resampled ATR >= 0.8x its own 30-day rolling median — blocks low-volatility
#     fakeout breakouts. Exits always derive from the RAW signals (never gated).
#   * 60-day time stop (weak-adopt, hygiene against zombie positions).
#   * signal_atr_mult / stop_atr_mult defaults = merge-comparison winner
#     (candidates C1=1.9/3.0, C2=2.0/2.0, C3=2.0/3.0; frozen after selection).
# Deployment form: 12-coin universe, max_open_trades 6 (Agent-H adoption:
# profit x3.4 with wallet-DD neutral vs MOT3 on the same universe).
from datetime import datetime, timedelta

from pandas import DataFrame

from freqtrade.persistence import Trade

from OPT1_VolatilitySystem import OPT1_VolatilitySystem


class OPT4_VolatilitySystem(OPT1_VolatilitySystem):
    # --- phase-4 knobs (defaults finalized by the C1/C2/C3 merge comparison) ---
    # signal_atr_mult / stop_atr_mult are inherited DecimalParameters; subclasses
    # of this file pin their defaults per candidate. After selection the winner's
    # values are re-declared here (optimize=False, frozen for dry-run).
    gate_atr_mult = 0.8            # atr08: entries need ATR >= 0.8 x 30d median
    gate_atr_window = 30 * 24      # 30d rolling median of resampled ATR (1h rows)
    gate_atr_min_periods = 7 * 24
    time_stop_days = 60

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe = super().populate_indicators(dataframe, metadata)
        dataframe["gate_atr_med"] = (
            dataframe["atr_raw"]
            .rolling(self.gate_atr_window, min_periods=self.gate_atr_min_periods)
            .median()
        )
        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # raw signals first (identical to OPT1) ...
        thr = dataframe["atr_raw"].shift(1) * self.signal_atr_mult.value
        long_sig = dataframe["close_change"] > thr
        short_sig = dataframe["close_change"] * -1 > thr
        # ... then the atr08 gate on NEW entries only (NaN median -> blocked)
        gate = (dataframe["atr_raw"] >= self.gate_atr_mult * dataframe["gate_atr_med"]).fillna(False)
        dataframe["enter_long"] = 0
        dataframe["enter_short"] = 0
        dataframe.loc[long_sig & gate, "enter_long"] = 1
        dataframe.loc[short_sig & gate, "enter_short"] = 1
        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # identical to OPT1: exits derive from the RAW signals, never from the gate
        thr = dataframe["atr_raw"].shift(1) * self.signal_atr_mult.value
        long_sig = dataframe["close_change"] > thr
        short_sig = dataframe["close_change"] * -1 > thr
        dataframe["exit_long"] = 0
        dataframe["exit_short"] = 0
        dataframe.loc[short_sig, "exit_long"] = 1
        dataframe.loc[long_sig, "exit_short"] = 1
        return dataframe

    def custom_exit(self, pair: str, trade: Trade, current_time: datetime,
                    current_rate: float, current_profit: float, **kwargs):
        if (current_time - trade.open_date_utc).days >= self.time_stop_days:
            return "time_stop_60d"
        return None
