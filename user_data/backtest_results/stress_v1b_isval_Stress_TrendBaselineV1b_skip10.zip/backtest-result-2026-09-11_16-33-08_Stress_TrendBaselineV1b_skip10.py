
import numpy as np
from pandas import DataFrame
from TrendBaselineV1b import TrendBaselineV1b as _Base


class Stress_TrendBaselineV1b_skip10(_Base):
    """Randomly skip 10% of entry signals (stress: missed fills). Seed fixed."""

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe = _Base.populate_entry_trend(self, dataframe, metadata)
        rng = np.random.default_rng(42)
        mask = rng.random(len(dataframe)) < 0.1
        for col in ("enter_long", "enter_short"):
            if col in dataframe.columns:
                dataframe.loc[mask, col] = 0.0
        return dataframe
