import sys
sys.path.insert(0, "/Users/caihaohan/ZCodeProject/freqtrade-futures-lab/user_data/strategies/oss")
from pandas import DataFrame
from OPT1_VolatilitySystem import OPT1_VolatilitySystem as _Base


class Stress_OPT1_VolatilitySystem_delay2(_Base):
    """Entry delayed by 2 candle(s) (stress: latency, replicates scripts/stress_test.py DELAY_TMPL)."""

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe = _Base.populate_entry_trend(self, dataframe, metadata)
        for col in ("enter_long", "enter_short"):
            if col in dataframe.columns:
                dataframe[col] = dataframe[col].shift(2).fillna(0.0)
        return dataframe