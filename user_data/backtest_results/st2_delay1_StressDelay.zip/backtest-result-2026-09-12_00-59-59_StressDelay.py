from pandas import DataFrame
from SupertrendMa import SupertrendMa as _Base


class StressDelay(_Base):
    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe = _Base.populate_entry_trend(self, dataframe, metadata)
        for col in ("enter_long", "enter_short"):
            if col in dataframe.columns:
                dataframe[col] = dataframe[col].shift(1).fillna(0.0)
        return dataframe
