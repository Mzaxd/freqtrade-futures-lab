
from TrendBaselineV1b import TrendBaselineV1b as _Base
from freqtrade.strategy import IntParameter, DecimalParameter


class Stress_TrendBaselineV1b_joint_p10(_Base):
    """Perturbed: all params +10%"""

    adx_min = IntParameter(15, 30, default=19, space='buy')
    atr_stop_mult = DecimalParameter(2.0, 6.0, default=2.86, decimals=1, space='sell')
    atr_trail_mult = DecimalParameter(1.0, 5.0, default=4.62, decimals=1, space='sell')
