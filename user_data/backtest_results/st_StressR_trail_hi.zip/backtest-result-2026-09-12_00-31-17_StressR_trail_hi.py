
from regime_router import RegimeRouter as _Base


class StressR_trail_hi(_Base):
    """perturbed:     TL_ATR_TRAIL = 4.6
    TS_ATR_TRAIL = 4.6"""
    TL_ATR_TRAIL = 4.6
    TS_ATR_TRAIL = 4.6
