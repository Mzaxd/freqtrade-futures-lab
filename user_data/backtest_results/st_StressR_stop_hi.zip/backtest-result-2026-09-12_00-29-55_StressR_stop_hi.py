
from regime_router import RegimeRouter as _Base


class StressR_stop_hi(_Base):
    """perturbed:     TL_ATR_STOP = 3.3
    TS_ATR_STOP = 3.3
    MR_ATR_STOP = 2.2"""
    TL_ATR_STOP = 3.3
    TS_ATR_STOP = 3.3
    MR_ATR_STOP = 2.2
