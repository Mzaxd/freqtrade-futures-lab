# Sub-strategy A: Donchian breakout, long-only, 4h.
# Routed mode gates entries to regime==trend_up and scales risk by regime
# confidence; standalone mode (REGIME_GATED=False) is used for the routing-gain
# comparison. Exits: opposite channel cross, ATR initial stop, ATR trailing
# stop, time stop. No martingale / no adding / stoploss always present.
from datetime import datetime, timedelta

import talib.abstract as ta
from pandas import DataFrame

from freqtrade.persistence import Trade
from freqtrade.strategy import (
    IStrategy,
    IntParameter,
    DecimalParameter,
    stoploss_from_absolute,
)

from regime_loader import attach_regime, risk_scale_for_regime


class MomentumBreakout(IStrategy):
    INTERFACE_VERSION = 3
    timeframe = "4h"
    can_short = False
    process_only_new_candles = True
    startup_candle_count = 400

    order_types = {"entry": "market", "exit": "market", "stoploss": "market",
                   "stoploss_on_exchange": False}
    minimal_roi = {"0": 100.0}
    stoploss = -0.30  # catastrophe backstop
    use_custom_stoploss = True
    position_adjustment_enable = False

    # routing switch: True = only trade in trend_up with confidence-scaled risk
    REGIME_GATED = False
    REGIME_STATE = 0  # trend_up

    # ---------------- tunable parameters ----------------
    entry_lookback = IntParameter(18, 42, default=24, space="buy")   # 4d on 4h
    exit_lookback = IntParameter(8, 24, default=12, space="sell")    # 2d on 4h
    atr_stop_mult = DecimalParameter(2.0, 4.0, default=3.0, decimals=1, space="sell")
    atr_trail_mult = DecimalParameter(1.0, 4.0, default=2.5, decimals=1, space="sell")
    base_risk = 0.010          # 1.0% equity risk per trade (routed: x conf)
    leverage_fixed = 3
    time_stop_hours = 24 * 14
    min_conf = 0.35
    # ------------------------------------------------------

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe["atr"] = ta.ATR(dataframe, timeperiod=14)
        lb = int(self.entry_lookback.value)
        xb = int(self.exit_lookback.value)
        dataframe["dc_high"] = dataframe["high"].rolling(lb).max().shift(1)
        dataframe["dc_exit_low"] = dataframe["low"].rolling(xb).min().shift(1)
        if self.REGIME_GATED:
            dataframe = attach_regime(dataframe, metadata["pair"])
        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        ok = (dataframe["close"] > dataframe["dc_high"]) & (dataframe["volume"] > 0)
        if self.REGIME_GATED:
            ok &= (dataframe["regime"] == self.REGIME_STATE) & (dataframe["conf"] >= self.min_conf)
        dataframe.loc[ok, "enter_long"] = 1
        dataframe.loc[ok, "enter_tag"] = "momentum"
        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe.loc[
            (dataframe["close"] < dataframe["dc_exit_low"]) & (dataframe["volume"] > 0),
            "exit_long",
        ] = 1
        return dataframe

    # ------------------------------------------------------------------ shared plumbing
    def _signal_candle(self, pair: str, until: datetime):
        df, _ = self.dp.get_analyzed_dataframe(pair, self.timeframe)
        return df, df["date"].searchsorted(until) - 1

    def leverage(self, pair: str, current_time: datetime, current_rate: float,
                 proposed_leverage: float, max_leverage: float, entry_tag,
                 side: str, **kwargs) -> float:
        return min(self.leverage_fixed, max_leverage)

    def custom_stake_amount(self, pair: str, current_time: datetime, current_rate: float,
                            proposed_stake: float, min_stake, max_stake: float,
                            leverage: float, entry_tag, side: str, **kwargs) -> float:
        try:
            df, idx = self._signal_candle(pair, current_time)
            row = df.iloc[idx]
            stop_pct = max(float(self.atr_stop_mult.value) * float(row["atr"]) / float(row["close"]), 0.005)
            risk = self.base_risk
            if self.REGIME_GATED:
                conf = float(row.get("conf", 1.0) or 1.0)
                risk = risk_scale_for_regime(int(row.get("regime", -1)), conf, self.base_risk)
                if risk <= 0:
                    return 0.0
            equity = self.wallets.get_total_stake_amount()
            stake = equity * risk / stop_pct / max(leverage, 1.0)
            stake = min(stake, equity * 0.35, max_stake)
            if min_stake is not None:
                stake = max(stake, min_stake)
            return stake
        except Exception:
            return proposed_stake

    def custom_stoploss(self, pair: str, trade: Trade, current_time: datetime,
                        current_rate: float, current_profit: float, after_fill: bool,
                        **kwargs):
        try:
            df, idx = self._signal_candle(pair, trade.open_date_utc)
            atr_entry = float(df.iloc[idx]["atr"])
        except Exception:
            return None
        if not atr_entry or atr_entry <= 0:
            return None
        lev = trade.leverage or 1.0
        initial = trade.open_rate - self.atr_stop_mult.value * atr_entry
        extreme = trade.max_rate or trade.open_rate
        trail = extreme - self.atr_trail_mult.value * atr_entry
        return stoploss_from_absolute(max(initial, trail), current_rate,
                                      is_short=False, leverage=lev)

    def custom_exit(self, pair: str, trade: Trade, current_time: datetime,
                    current_rate: float, current_profit: float, **kwargs):
        if current_time - trade.open_date_utc > timedelta(hours=self.time_stop_hours):
            return "time_stop"
        return None
