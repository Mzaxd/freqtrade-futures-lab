from pandas import DataFrame
from OPT4_VolatilitySystem import OPT4_VolatilitySystem


class OPT4_StressDelay1(OPT4_VolatilitySystem):
    """Entry delayed by 1 candle(s) (stress: latency)."""
    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe = OPT4_VolatilitySystem.populate_entry_trend(self, dataframe, metadata)
        for col in ("enter_long", "enter_short"):
            if col in dataframe.columns:
                dataframe[col] = dataframe[col].shift(1).fillna(0.0)
        return dataframe
