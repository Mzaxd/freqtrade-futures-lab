import numpy as np
from pandas import DataFrame
from OPT4_VolatilitySystem import OPT4_VolatilitySystem


class OPT4_StressSkip20(OPT4_VolatilitySystem):
    """Randomly skip 20% of entry signals (stress: missed fills). Seed 42."""
    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe = OPT4_VolatilitySystem.populate_entry_trend(self, dataframe, metadata)
        rng = np.random.default_rng(42)
        mask = rng.random(len(dataframe)) < 20/100.0
        for col in ("enter_long", "enter_short"):
            if col in dataframe.columns:
                dataframe.loc[mask, col] = 0.0
        return dataframe
