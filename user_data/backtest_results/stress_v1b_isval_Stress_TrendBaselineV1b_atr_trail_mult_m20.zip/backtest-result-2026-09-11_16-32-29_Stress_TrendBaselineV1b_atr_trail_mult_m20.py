
from TrendBaselineV1b import TrendBaselineV1b as _Base
from freqtrade.strategy import IntParameter, DecimalParameter


class Stress_TrendBaselineV1b_atr_trail_mult_m20(_Base):
    """Perturbed: atr_trail_mult: 4.2 -> 3.36 (-20%)"""

    atr_trail_mult = DecimalParameter(1.0, 5.0, default=3.36, decimals=1, space='sell')
