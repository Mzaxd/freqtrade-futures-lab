
from TrendBaselineV1b import TrendBaselineV1b as _Base
from freqtrade.strategy import IntParameter, DecimalParameter


class Stress_TrendBaselineV1b_atr_trail_mult_m10(_Base):
    """Perturbed: atr_trail_mult: 4.2 -> 3.78 (-10%)"""

    atr_trail_mult = DecimalParameter(1.0, 5.0, default=3.78, decimals=1, space='sell')
