
from regime_router import RegimeRouter as _Base


class StressR_rrm_hi(_Base):
    """perturbed:     RANGE_RISK_MULT = 0.55"""
    RANGE_RISK_MULT = 0.55
