
from regime_router import RegimeRouter as _Base


class StressR_rrm_lo(_Base):
    """perturbed:     RANGE_RISK_MULT = 0.45"""
    RANGE_RISK_MULT = 0.45
