
from TrendBaselineV1b import TrendBaselineV1b as _Base
from freqtrade.strategy import IntParameter, DecimalParameter


class Stress_TrendBaselineV1b_atr_stop_mult_m20(_Base):
    """Perturbed: atr_stop_mult: 2.6 -> 2.08 (-20%)"""

    atr_stop_mult = DecimalParameter(2.0, 6.0, default=2.08, decimals=1, space='sell')
