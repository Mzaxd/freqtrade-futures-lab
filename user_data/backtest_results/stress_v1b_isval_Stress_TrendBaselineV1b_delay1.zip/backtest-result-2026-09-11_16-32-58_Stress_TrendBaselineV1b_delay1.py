
from pandas import DataFrame
from TrendBaselineV1b import TrendBaselineV1b as _Base


class Stress_TrendBaselineV1b_delay1(_Base):
    """Entry delayed by 1 candle(s) (stress: latency)."""

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe = _Base.populate_entry_trend(self, dataframe, metadata)
        for col in ("enter_long", "enter_short"):
            if col in dataframe.columns:
                dataframe[col] = dataframe[col].shift(1).fillna(0.0)
        return dataframe
