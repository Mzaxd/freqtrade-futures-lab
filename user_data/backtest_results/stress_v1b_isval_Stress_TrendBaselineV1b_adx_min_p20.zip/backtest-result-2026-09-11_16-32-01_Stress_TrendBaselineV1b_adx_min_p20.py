
from TrendBaselineV1b import TrendBaselineV1b as _Base
from freqtrade.strategy import IntParameter, DecimalParameter


class Stress_TrendBaselineV1b_adx_min_p20(_Base):
    """Perturbed: adx_min: 17 -> 20 (+20%)"""

    adx_min = IntParameter(15, 30, default=20, space='buy')
