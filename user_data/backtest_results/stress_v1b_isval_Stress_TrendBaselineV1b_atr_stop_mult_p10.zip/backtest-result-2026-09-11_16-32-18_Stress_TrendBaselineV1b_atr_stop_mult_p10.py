
from TrendBaselineV1b import TrendBaselineV1b as _Base
from freqtrade.strategy import IntParameter, DecimalParameter


class Stress_TrendBaselineV1b_atr_stop_mult_p10(_Base):
    """Perturbed: atr_stop_mult: 2.6 -> 2.86 (+10%)"""

    atr_stop_mult = DecimalParameter(2.0, 6.0, default=2.86, decimals=1, space='sell')
