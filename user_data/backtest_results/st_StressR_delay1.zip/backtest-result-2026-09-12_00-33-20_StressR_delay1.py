
from pandas import DataFrame
from regime_router import RegimeRouter as _Base


class StressR_delay1(_Base):
    """Entry delayed by 1 candle (stress: latency)."""

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe = _Base.populate_entry_trend(self, dataframe, metadata)
        for col in ("enter_long", "enter_short"):
            if col in dataframe.columns:
                dataframe[col] = dataframe[col].shift(1).fillna(0.0)
        return dataframe
