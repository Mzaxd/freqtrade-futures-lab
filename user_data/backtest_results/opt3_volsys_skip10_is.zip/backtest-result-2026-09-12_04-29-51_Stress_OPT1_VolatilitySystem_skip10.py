import sys
sys.path.insert(0, "/Users/caihaohan/ZCodeProject/freqtrade-futures-lab/user_data/strategies/oss")
import numpy as np
from pandas import DataFrame
from OPT1_VolatilitySystem import OPT1_VolatilitySystem as _Base


class Stress_OPT1_VolatilitySystem_skip10(_Base):
    """Randomly skip 10% of entry signals (stress: missed fills, replicates scripts/stress_test.py SKIP_TMPL). Seed fixed."""

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe = _Base.populate_entry_trend(self, dataframe, metadata)
        rng = np.random.default_rng(42)
        mask = rng.random(len(dataframe)) < 0.1
        for col in ("enter_long", "enter_short"):
            if col in dataframe.columns:
                dataframe.loc[mask, col] = 0.0
        return dataframe