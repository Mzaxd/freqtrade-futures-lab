
from regime_router import RegimeRouter as _Base


class StressR_trail_lo(_Base):
    """perturbed:     TL_ATR_TRAIL = 3.8
    TS_ATR_TRAIL = 3.8"""
    TL_ATR_TRAIL = 3.8
    TS_ATR_TRAIL = 3.8
